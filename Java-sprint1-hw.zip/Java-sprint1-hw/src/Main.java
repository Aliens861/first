import java.util.Objects;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int newDaily;
        int stepsToday;
        StepTracker stpTrk = new StepTracker();
        int monthSelection;
        while (true) {
            printMenu();
            String userInput = scanner.next();
            try
            {
                int number = Integer.parseInt(userInput);
                if (number == 1) {
                    System.out.println("");
                    System.out.println("Введите месяц:");
                    int m= scanner.nextInt();
                    System.out.println("Введите день:");
                    int d= scanner.nextInt();
                    System.out.println("Введите шаги:");
                    stepsToday = scanner.nextInt();
                    stpTrk.recordSteps(m,d,stepsToday);
                } else if (number == 2) {
                    System.out.println("Выберите месяц: ");
                    monthSelection = scanner.nextInt();
                    stpTrk.countMonthSteps(monthSelection);
                } else if (number == 3) {
                    System.out.println("Введите свою цель: ");
                    newDaily=scanner.nextInt();
                    stpTrk.changeDaily(newDaily);
                    System.out.println("Новая цель введена: " + newDaily);
                } else if (number == 4) {
                    System.out.println("Вы уверены, что хотите выйти? (yes/no)");
                    String exit = scanner.next();
                    if (Objects.equals(exit, "yes"))
                    {
                        break;
                    }
                    else
                    {
                        if (Objects.equals(exit, "no"))
                        {
                            System.out.println("Возвращаемся в меню...");
                        }
                    }
                }
                else
                {
                    System.out.println("Неизвестная команда, попробуйте ещё раз");
                }
            }
            catch (Exception e)
            {
                System.out.println("Неизвестная команда, введите ещё раз");
            }
        }
    }
    public static void printMenu() {
        System.out.println("Счётчик калорий");
        System.out.println("1 - Ввести количество шагов за определённый день");
        System.out.println("2 - Напечатать статистику за определённый месяц");
        System.out.println("3 - Изменить цель по количеству шагов в день");
        System.out.println("4 - Выход");
    }
}