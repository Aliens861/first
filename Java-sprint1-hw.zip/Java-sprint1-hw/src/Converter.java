public class Converter
{
    public void countData(int monthSum)
    {
        System.out.println("Пройденная дистанция за месяц: " + (monthSum * 75)/100000 + " km");
    }
    public int countKcal(int monthSum)
    {
        System.out.println("Потраченные килокалории: " + (monthSum * 50)/1000 + " ");
        return 0;
    }
}