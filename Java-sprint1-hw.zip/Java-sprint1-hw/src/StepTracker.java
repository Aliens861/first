

public class StepTracker {
    Converter conv = new Converter();

    public StepTracker() {
    }
    int sum = 0;
    public int monthSum = 0;

    int maxSteps;
    int topSeries;
    int[][] yearArray = new int[12][30];

    public int recordSteps(int m, int d, int stepsToday) {
        yearArray[m][d] = stepsToday;
        sum = sum + yearArray[m][d];
        return 0;
    }

    public int plannedDaily = 10000;

    public void countMonthSteps(int m) {
                for (int i = 1; i < 30; i++) {
                        System.out.println("День " + i + ": " + yearArray[m][i]);
                        monthSum += yearArray[m][i]; //Month Sum
                        maxStep(yearArray[m][i]);
                        if (yearArray[m][i] >= plannedDaily) {
                            topSeries++;
                        }
                    }



        System.out.println("Сумма за месяц: " + monthSum);
        System.out.println("Максимальное количество шагов: " + maxSteps);
        System.out.println("Среднее число шагов: " + (monthSum / 30));
        conv.countData(monthSum);
        conv.countKcal(monthSum);
        System.out.println("Лучшая серия: " + topSeries);
        System.out.println("-------------------------------------");
    }

    public int maxStep(int steps) {
        maxSteps = steps;
        if (steps > maxSteps){

    }
        return maxSteps;
}
    public void changeDaily (int newDaily)
    {
        plannedDaily = newDaily;
    }

}